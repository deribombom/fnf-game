# Beat Battle - iPhone Website

This folder is ready to upload to a static website host.

- Main file: `index.html`
- No external libraries or assets are required.
- Open the published website on an iPhone and tap START GAME.
- Use the four big touchscreen arrows to play.

For GitHub Pages:
1. Create a GitHub repository.
2. Upload `index.html` to the repository.
3. Enable GitHub Pages for the repository.
4. Open the Pages URL on your iPhone.
